package com.internal.tasktracker;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.data.domain.PageRequest;

import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
class TaskRepositoryTest {

    @Autowired
    private TaskRepository taskRepository;

    @Test
    void searchAppliesArchivedAndStatusFiltersToBothSearchFields() {
        Task result = taskRepository.searchTasks(
                "%api%",
                "OPEN",
                PageRequest.of(0, 10)
        ).getContent().stream()
         .findFirst()
         .orElseThrow();

        assertThat(result.isArchived()).isFalse();
        assertThat(result.getStatus()).isEqualTo("OPEN");
        assertThat((result.getTitle() + " " + result.getDescription()).toLowerCase())
                .contains("api");
    }

    @Test
    void searchPaginatesAtDatabaseLayer() {
        var page = taskRepository.searchTasks(
                "%%",
                null,
                PageRequest.of(0, 2)
        );

        assertThat(page.getContent()).hasSize(2);
        assertThat(page.getTotalElements()).isGreaterThan(2);
    }
}
