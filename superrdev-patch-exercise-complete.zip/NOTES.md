# Patch Notes

## Summary of changes

I focused on four high-value issues in the task search flow:

1. Fixed the SQL boolean-precedence bug so the archived filter and optional status filter apply to both title and description matches.
2. Replaced in-memory pagination with Spring Data `Page` pagination, so the database returns only the requested page and calculates the total count separately.
3. Removed the artificial `Thread.sleep` delay based on search-term length and added bounded pagination inputs plus a clear 400 response for invalid statuses.
4. Improved the React search flow with a short debounce, request cancellation, stale-error clearing, and page reset when filters change.

I also updated the Oracle/reference SQL to match the corrected filtering semantics and added repository regression tests for filtering and pagination.

## What I chose not to change

I did not redesign the UI, add authentication, or introduce a new database abstraction. Those changes are outside the core search path and would make the patch larger without addressing the highest-value defects.

I also did not convert the whole API to DTOs because that would be a broader architectural change for this timeboxed exercise.

## Biggest remaining risk

The application still exposes the H2 console and has no authentication/authorization layer. That is acceptable for this exercise but would need to be addressed before production use.

## Tools/AI

I used ChatGPT to inspect the code, identify likely failure modes, draft focused fixes, and suggest regression tests. I reviewed and adjusted the changes to preserve the original Spring Boot/Vite structure and startup commands. Local Maven execution in this environment could not download the Maven wrapper distribution, so the final repository should be verified locally before submission.
