HANDWRITTEN NOTES REQUIRED BY THE ASSIGNMENT

Please write the following points by hand on paper, photograph/scan them, and place the image files in this folder.

Page 1 — SQL filtering bug
- File: backend/src/main/java/com/internal/tasktracker/TaskRepository.java
- Discovery: tested a search with a status filter and inspected the WHERE clause.
- Root cause: SQL AND has higher precedence than OR, so archived/status conditions did not apply to every title/description match.
- Fix: grouped title/description with parentheses, then applied archived and status conditions.
- Why: makes the intended boolean logic explicit and prevents incorrect results.

Page 2 — Pagination/performance
- Files: TaskRepository.java and TaskController.java
- Discovery: repository returned every matching row and Java used subList for pagination.
- Root cause: database was doing filtering but application memory was doing pagination.
- Fix: changed repository to return Spring Data Page and added a count query.
- Why: only the requested page is loaded and page size is bounded.

Page 3 — Request handling
- File: TaskController.java
- Discovery: search requests slept for a duration derived from query length and accepted arbitrary page sizes.
- Root cause: artificial blocking work plus unbounded input.
- Fix: removed sleep, normalized inputs, bounded page size, and return 400 for invalid status.
- Why: prevents avoidable latency/resource exhaustion and gives clients a useful validation error.

Page 4 — React request race
- File: frontend/src/hooks/useTasks.js
- Discovery: search fires on every keystroke and older requests can finish after newer requests.
- Root cause: no debounce or cancellation.
- Fix: 250ms debounce and AbortController; errors are cleared for each new request.
- Why: fewer requests and no stale response/error overwriting current state.

Page 5 — Pagination reset
- File: frontend/src/App.jsx
- Discovery: changing a filter while viewing a later page can request a page that does not exist for the new result set.
- Fix: reset to page 1 when query/status changes.
- Why: keeps the displayed page valid after filtering.

IMPORTANT: These are prompts for your own handwritten explanation. Add your actual handwritten photos/scans here before submission.
