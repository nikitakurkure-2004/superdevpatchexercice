package com.internal.tasktracker;

public class InvalidTaskFilterException extends RuntimeException {
    public InvalidTaskFilterException(String message) {
        super(message);
    }
}
